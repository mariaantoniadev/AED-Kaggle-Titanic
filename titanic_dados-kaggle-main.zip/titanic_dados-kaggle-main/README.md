# titanic_dados-kaggle
Aula do dia 23/10 de Estrutura de Dados - Kaggle | Dados do Titanic 
